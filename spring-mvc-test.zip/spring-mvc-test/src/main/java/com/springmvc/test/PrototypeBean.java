package com.springmvc.test;

public class PrototypeBean {

	public PrototypeBean() {
		System.out.println("PrototypeBean instance created");
	}

}
