package com.springmvc.test;

public class MainClass {
	
	public static void getMainClass() {
		System.out.println("https://www.baeldung.com/spring-inject-prototype-bean-into-singleton");
	}

}
